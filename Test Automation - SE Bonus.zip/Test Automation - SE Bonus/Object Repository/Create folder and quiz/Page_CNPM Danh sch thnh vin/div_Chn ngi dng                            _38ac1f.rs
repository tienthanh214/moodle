<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Chn ngi dng                            _38ac1f</name>
   <tag></tag>
   <elementGuidId>e7e45994-151a-430c-a85c-3282b5649a9e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#yui_3_17_2_1_1641376933974_208</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='yui_3_17_2_1_1641376933974_208']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fcontainer clearfix</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>yui_3_17_2_1_1641376933974_208</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
		
    
        
                
                    Chọn người dùng
                
        
        
            
        
    
    
            
        
        
    
    Student Nguyen
    student@gmail.com

    
    Teacher Nguyen
    teacher@gmail.com

    
    Test Nguyễn
    abc@gmail.com

    
    Quản trị Thành viên
    admin@mdl.com

        
            
        
    Selected items:

        × 
    
    Student Nguyen
    student@gmail.com

    

    
    ▼


        
    
    Teacher Nguyen
    teacher@gmail.com

        
    
    Test Nguyễn
    abc@gmail.com

        
    
    Quản trị Thành viên
    admin@mdl.com



    
        
                
                    Chỉ định vai trò
                
        
        
            
        
    
    
        
            Người quản lý
            Giáo viên
            Giáo viên trợ giảng
            Học viên
        
        
            
        
    
Show more...
    
    
    
        
            
                
                    Phục hồi điểm số cũ của người dùng nếu có thể
                
            
                
            
        
        
            
        
    

    
        
                
                    Bắt đầu từ
                
        
        
            
        
    
    
        
            Khóa học bắt đầu (10/09/21)
            Hôm nay (5/01/22)
            Bây giờ (5/01/2022 18:02)
        
        
            
        
    

    
        
                
                    Thời hạn ghi danh
                
        
        
            
        
    
    
        
            Không giới hạn
            1 ngày
            2 ngày
            3 ngày
            4 ngày
            5 ngày
            6 ngày
            7 ngày
            8 ngày
            9 ngày
            10 ngày
            11 ngày
            12 ngày
            13 ngày
            14 ngày
            15 ngày
            16 ngày
            17 ngày
            18 ngày
            19 ngày
            20 ngày
            21 ngày
            22 ngày
            23 ngày
            24 ngày
            25 ngày
            26 ngày
            27 ngày
            28 ngày
            29 ngày
            30 ngày
            31 ngày
            32 ngày
            33 ngày
            34 ngày
            35 ngày
            36 ngày
            37 ngày
            38 ngày
            39 ngày
            40 ngày
            41 ngày
            42 ngày
            43 ngày
            44 ngày
            45 ngày
            46 ngày
            47 ngày
            48 ngày
            49 ngày
            50 ngày
            51 ngày
            52 ngày
            53 ngày
            54 ngày
            55 ngày
            56 ngày
            57 ngày
            58 ngày
            59 ngày
            60 ngày
            61 ngày
            62 ngày
            63 ngày
            64 ngày
            65 ngày
            66 ngày
            67 ngày
            68 ngày
            69 ngày
            70 ngày
            71 ngày
            72 ngày
            73 ngày
            74 ngày
            75 ngày
            76 ngày
            77 ngày
            78 ngày
            79 ngày
            80 ngày
            81 ngày
            82 ngày
            83 ngày
            84 ngày
            85 ngày
            86 ngày
            87 ngày
            88 ngày
            89 ngày
            90 ngày
            91 ngày
            92 ngày
            93 ngày
            94 ngày
            95 ngày
            96 ngày
            97 ngày
            98 ngày
            99 ngày
            100 ngày
            101 ngày
            102 ngày
            103 ngày
            104 ngày
            105 ngày
            106 ngày
            107 ngày
            108 ngày
            109 ngày
            110 ngày
            111 ngày
            112 ngày
            113 ngày
            114 ngày
            115 ngày
            116 ngày
            117 ngày
            118 ngày
            119 ngày
            120 ngày
            121 ngày
            122 ngày
            123 ngày
            124 ngày
            125 ngày
            126 ngày
            127 ngày
            128 ngày
            129 ngày
            130 ngày
            131 ngày
            132 ngày
            133 ngày
            134 ngày
            135 ngày
            136 ngày
            137 ngày
            138 ngày
            139 ngày
            140 ngày
            141 ngày
            142 ngày
            143 ngày
            144 ngày
            145 ngày
            146 ngày
            147 ngày
            148 ngày
            149 ngày
            150 ngày
            151 ngày
            152 ngày
            153 ngày
            154 ngày
            155 ngày
            156 ngày
            157 ngày
            158 ngày
            159 ngày
            160 ngày
            161 ngày
            162 ngày
            163 ngày
            164 ngày
            165 ngày
            166 ngày
            167 ngày
            168 ngày
            169 ngày
            170 ngày
            171 ngày
            172 ngày
            173 ngày
            174 ngày
            175 ngày
            176 ngày
            177 ngày
            178 ngày
            179 ngày
            180 ngày
            181 ngày
            182 ngày
            183 ngày
            184 ngày
            185 ngày
            186 ngày
            187 ngày
            188 ngày
            189 ngày
            190 ngày
            191 ngày
            192 ngày
            193 ngày
            194 ngày
            195 ngày
            196 ngày
            197 ngày
            198 ngày
            199 ngày
            200 ngày
            201 ngày
            202 ngày
            203 ngày
            204 ngày
            205 ngày
            206 ngày
            207 ngày
            208 ngày
            209 ngày
            210 ngày
            211 ngày
            212 ngày
            213 ngày
            214 ngày
            215 ngày
            216 ngày
            217 ngày
            218 ngày
            219 ngày
            220 ngày
            221 ngày
            222 ngày
            223 ngày
            224 ngày
            225 ngày
            226 ngày
            227 ngày
            228 ngày
            229 ngày
            230 ngày
            231 ngày
            232 ngày
            233 ngày
            234 ngày
            235 ngày
            236 ngày
            237 ngày
            238 ngày
            239 ngày
            240 ngày
            241 ngày
            242 ngày
            243 ngày
            244 ngày
            245 ngày
            246 ngày
            247 ngày
            248 ngày
            249 ngày
            250 ngày
            251 ngày
            252 ngày
            253 ngày
            254 ngày
            255 ngày
            256 ngày
            257 ngày
            258 ngày
            259 ngày
            260 ngày
            261 ngày
            262 ngày
            263 ngày
            264 ngày
            265 ngày
            266 ngày
            267 ngày
            268 ngày
            269 ngày
            270 ngày
            271 ngày
            272 ngày
            273 ngày
            274 ngày
            275 ngày
            276 ngày
            277 ngày
            278 ngày
            279 ngày
            280 ngày
            281 ngày
            282 ngày
            283 ngày
            284 ngày
            285 ngày
            286 ngày
            287 ngày
            288 ngày
            289 ngày
            290 ngày
            291 ngày
            292 ngày
            293 ngày
            294 ngày
            295 ngày
            296 ngày
            297 ngày
            298 ngày
            299 ngày
            300 ngày
            301 ngày
            302 ngày
            303 ngày
            304 ngày
            305 ngày
            306 ngày
            307 ngày
            308 ngày
            309 ngày
            310 ngày
            311 ngày
            312 ngày
            313 ngày
            314 ngày
            315 ngày
            316 ngày
            317 ngày
            318 ngày
            319 ngày
            320 ngày
            321 ngày
            322 ngày
            323 ngày
            324 ngày
            325 ngày
            326 ngày
            327 ngày
            328 ngày
            329 ngày
            330 ngày
            331 ngày
            332 ngày
            333 ngày
            334 ngày
            335 ngày
            336 ngày
            337 ngày
            338 ngày
            339 ngày
            340 ngày
            341 ngày
            342 ngày
            343 ngày
            344 ngày
            345 ngày
            346 ngày
            347 ngày
            348 ngày
            349 ngày
            350 ngày
            351 ngày
            352 ngày
            353 ngày
            354 ngày
            355 ngày
            356 ngày
            357 ngày
            358 ngày
            359 ngày
            360 ngày
            361 ngày
            362 ngày
            363 ngày
            364 ngày
            365 ngày
        
        
            
        
    

    
                    
                Thời hạn ghi danh kết thúc
            

        
            
        
    
    
        
            Thời hạn ghi danh kết thúc
            
                
                
        
            Ngày
        
    
    
        1
        2
        3
        4
        5
        6
        7
        8
        9
        10
        11
        12
        13
        14
        15
        16
        17
        18
        19
        20
        21
        22
        23
        24
        25
        26
        27
        28
        29
        30
        31
    
    
    
        
    

                 
                
        
            Tháng
        
    
    
        Tháng Giêng
        Tháng Hai
        Tháng Ba
        Tháng Tư
        Tháng Năm
        Tháng Sáu
        Tháng Bảy
        Tháng Tám
        Tháng Chín
        Tháng Mười
        Tháng Mười Một
        Tháng Mười Hai
    
    
    
        
    

                 
                
        
            Năm
        
    
    
        1900
        1901
        1902
        1903
        1904
        1905
        1906
        1907
        1908
        1909
        1910
        1911
        1912
        1913
        1914
        1915
        1916
        1917
        1918
        1919
        1920
        1921
        1922
        1923
        1924
        1925
        1926
        1927
        1928
        1929
        1930
        1931
        1932
        1933
        1934
        1935
        1936
        1937
        1938
        1939
        1940
        1941
        1942
        1943
        1944
        1945
        1946
        1947
        1948
        1949
        1950
        1951
        1952
        1953
        1954
        1955
        1956
        1957
        1958
        1959
        1960
        1961
        1962
        1963
        1964
        1965
        1966
        1967
        1968
        1969
        1970
        1971
        1972
        1973
        1974
        1975
        1976
        1977
        1978
        1979
        1980
        1981
        1982
        1983
        1984
        1985
        1986
        1987
        1988
        1989
        1990
        1991
        1992
        1993
        1994
        1995
        1996
        1997
        1998
        1999
        2000
        2001
        2002
        2003
        2004
        2005
        2006
        2007
        2008
        2009
        2010
        2011
        2012
        2013
        2014
        2015
        2016
        2017
        2018
        2019
        2020
        2021
        2022
        2023
        2024
        2025
        2026
        2027
        2028
        2029
        2030
        2031
        2032
        2033
        2034
        2035
        2036
        2037
        2038
        2039
        2040
        2041
        2042
        2043
        2044
        2045
        2046
        2047
        2048
        2049
        2050
    
    
    
        
    

                 
                
        
            Giờ
        
    
    
        00
        01
        02
        03
        04
        05
        06
        07
        08
        09
        10
        11
        12
        13
        14
        15
        16
        17
        18
        19
        20
        21
        22
        23
    
    
    
        
    

                 
                
        
            Phút
        
    
    
        00
        01
        02
        03
        04
        05
        06
        07
        08
        09
        10
        11
        12
        13
        14
        15
        16
        17
        18
        19
        20
        21
        22
        23
        24
        25
        26
        27
        28
        29
        30
        31
        32
        33
        34
        35
        36
        37
        38
        39
        40
        41
        42
        43
        44
        45
        46
        47
        48
        49
        50
        51
        52
        53
        54
        55
        56
        57
        58
        59
    
    
    
        
    

                 
                
                 
                

    Mở



    

            
        
        
            
        
    

		</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;yui_3_17_2_1_1641376933974_208&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='yui_3_17_2_1_1641376933974_208']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='id_main']/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Các tùy biến ghi danh'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ghi danh người dùng'])[1]/following::div[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/fieldset/div</value>
   </webElementXpaths>
</WebElementEntity>

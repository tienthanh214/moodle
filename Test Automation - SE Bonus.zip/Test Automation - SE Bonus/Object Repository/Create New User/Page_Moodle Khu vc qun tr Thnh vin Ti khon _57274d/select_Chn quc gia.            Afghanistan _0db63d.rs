<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Chn quc gia.            Afghanistan _0db63d</name>
   <tag></tag>
   <elementGuidId>7d179292-35b3-436f-9e91-e64c906a35ab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='id_country']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#id_country</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>custom-select
                       
                       </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>country</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>id_country</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            Chọn quốc gia...
            Afghanistan
            Ai Cập
            Ai Len
            Áo
            Australia
            Ăng gô la
            Ấn Độ
            Ba Lan
            Belize
            Bermuda
            Bỉ
            Bolivia (Plurinational State of)
            Bosnia và  Herzegovina
            Bồ Đào Nha
            Bờ Biển Ngà
            Bra xin
            Bun ga ri
            Burkina Faso
            Ca na đa
            Ca-dắc-xtan
            Các Tiểu Vương quốc Ả Rập Thống nhất
            Caribe Hà Lan
            Căm pu chia
            Châu Nam Cực
            Chi Lê
            Cộng hòa Ả Rập Syria
            Cộng hòa Albania
            Cộng hòa Argentina
            Cộng hòa Armenia
            Cộng hòa Azerbaijan
            Cộng hòa Bắc Macedonia
            Cộng hòa Belarus
            Cộng hòa Benin
            Cộng hòa Bolivar Venezuela
            Cộng hòa Botswana
            Cộng hòa Burundi
            Cộng hòa Cabo Verde
            Cộng hòa Cameroon
            Cộng hòa Chad
            Cộng hòa Colombia
            Cộng hòa Costa Rica
            Cộng hòa Croatia
            Cộng hòa dân chủ Congo
            Cộng hoà Dân chủ Công gô
            Cộng hòa Dân chủ Liên bang Ethiopia
            Cộng hoà Dân chủ Liên bang Nepal
            Cộng hòa Dân chủ Nhân dân Algeria
            Cộng hòa Dân chủ Sao Tome and Principe
            Cộng hòa Djibouti
            Cộng Hoà Dominican
            Cộng hòa Đông Uruguay
            Cộng hòa Ecuador
            Cộng hòa El Salvador
            Cộng hòa Estonia
            Cộng hòa Fijji
            Cộng hòa Gabon
            Cộng hòa Gambia
            Cộng hòa Ghana
            Cộng hòa Guatemala
            Cộng hòa Guinea
            Cộng hòa Guinea-Bissau
            Cộng hòa Haiti
            Cộng hòa Hồi giáo Mô - ri - ta - ni
            Cộng hoà Hồi giáo Pakistan
            Cộng hoà Hợp tác Guyana
            Cộng hòa Indonesia
            Cộng hòa Kenya
            Cộng hòa Kiribati
            Cộng hòa Kyrgyzstan
            Cộng hòa Latvia
            Cộng hòa Li - băng
            Cộng hòa Liberia
            Cộng hòa Liên bang Nigeria
            Cộng hòa Liên bang Somalia
            Cộng hòa Lithuania
            Cộng hòa Madagascar
            Cộng hòa Malawi
            Cộng hòa Maldives
            Cộng hòa Mali
            Cộng hòa Malta
            Cộng hòa Mauritius
            Cộng hoà Moldova
            Cộng hòa Mozambique
            Cộng hòa Nam Phi
            Cộng hòa Nam Sudan
            Cộng hòa Namibia
            Cộng hòa Nauru
            Cộng hòa nhân dân Bangladesh
            Cộng hòa Nicaragua
            Cộng hòa Niger
            Cộng hòa Palau
            Cộng hòa Panama
            Cộng hòa Paraguay
            Cộng hòa Peru
            Cộng hòa Ru-an-đa
            Cộng hòa San Marino
            Cộng Hoà Séc
            Cộng hòa Senegal
            Cộng hòa Seychelles
            Cộng hòa Sierra Leone
            Cộng hòa Síp
            Cộng hòa Slovakia
            Cộng hòa Slovenia
            Cộng hòa Sudan
            Cộng hòa Suriname
            Cộng hòa Tajikistan
            Cộng hòa Thống nhất Tanzania
            Cộng hòa Trinidad và Tobago
            Cộng hoà Trung Phi
            Cộng hòa Tunisia
            Cộng hòa Uganda
            Cộng hòa Uzbekistan
            Cộng hòa Vanuatu
            Cộng hoà Xã hội chủ nghĩa Dân chủ Sri Lanka
            Cộng hòa Yemen
            Cộng hòa Zambia
            Cộng hòa Zimbabwe
            Cộng hoafa Honduras
            Cộng hoafa Togo
            Công quốc Andorra
            Công quốc Monaco
            Cu Ba
            Curaçao
            Đại công quốc Luxembourg
            Đài Loan
            Đan Mạch
            Đảo Anguilla
            Đảo Aruba
            Đảo Barbados
            Đảo Bouvet
            Đảo Dominica
            Đảo Giáng sinh
            Đảo Greenland
            Đảo Grenada
            Đảo Guadeloupe
            Đảo Jamaica
            Đảo Martinique
            Đảo Niue
            Đảo Norfolk
            Đảo Réunion
            Đảo Saint Helena, Ascension and Tristan da Cunha
            Đảo Svalbard và  Jan Mayen
            Đảo Tokelau
            Đông Timor
            Đức
            Georgia
            Gibraltar
            Guernsey
            Guiana Pháp
            Guinea Xích đạo
            Hà Lan
            Hàn Quốc
            Hi Lạp
            Hồng Công
            Hung ga ri
            I - ran
            I rắc
            Iceland
            Isle Of Man
            Jersey
            Kuwait
            Lãnh thổ Anh - Ấn trên biển
            Lãnh thổ Đảo Sint Maarten
            Lãnh thổ Guam
            Lãnh thổ hải ngoại thuộc Anh Montserrat
            Lãnh thổ quần đảo Wallis và Futuna[
            Lào
            Liên bang Comoros
            Liên bang Micronesia
            Liên bang Nga
            Liên bang Saint Kitts và Nevis
            Ma Cao
            Mã Lai
            Mê Hi Cô
            Miến Điện
            Montenegro
            Mông cổ
            Mỹ
            Na Uy
            Nam Georgia và Quần đảo South Sandwich
            Nhà nước Brunei Darussalam
            Nhà nước Độc lập Papua New Guinea
            Nhà nước Độc lập Samoa
            Nhà nước Eritrea
            Nhà nước Israel
            Nhà nước Li - bi
            Nhà nước Palestine
            Nhà nước Qatar
            Nhật Bản
            Pháp
            Phần Lan
            Phi líp pin
            Polynésie thuộc Pháp
            Quần đảo Ai Len
            Quần đảo Bahamas
            Quần đảo Cayman
            Quần đảo Cocos (Keeling)
            Quần đảo Cook
            Quần đảo Ellice
            Quần đảo Falkland (Malvinas)
            Quần đảo Faroe
            Quần đảo Heard và Mc Donald
            Quần đảo Marshall
            Quần đảo Northern Mariana
            Quần đảo Pitcairn
            Quần đảo Solomon
            Quần đảo Turks và Caicos
            Quần đảo Virgin thuộc Anh
            Quần đảo Virgin thuộc Mỹ
            Quốc đảo Antigua and Barbuda
            Rumani
            Saint Barthélemy
            Saint Martin
            Saint Vincent và Grenadines
            Samoa thuộc Mỹ
            Saudi Arabia
            Serbia
            Sinh ga po
            Tân Caledonia
            Tân Tây Lan
            Tây Ban Nha
            Tây Sahara
            Thái Lan
            Thân vương quốc Liechtenstein
            Thịnh vượng chung Puerto Rico
            Thịnh vượng chung Saint Lucia
            Thổ Nhĩ Kì
            Thuỵ Điển
            Thụy Sĩ
            Tỉnh Mayotte
            Tòa Thánh
            Triều Tiên
            Trung Quốc
            Tuốc-mê-ni-xtan
            U-crai-na
            United States Minor Outlying Islands
            Việt Nam
            Vùng đất phía Nam và châu Nam Cực thuộc Pháp
            Vùng lãnh thổ cộng đồng Saint-Pierre và Miquelon
            Vương Quốc Anh
            Vương quốc Bahrain
            Vương quốc Bhutan
            Vương quốc Eswatini
            Vương quốc Hồi giáo Oman
            Vương quốc Jordan
            Vương quốc Lesotho
            Vương quốc Ma - rốc
            Vương quốc Tonga
            Ý
        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;id_country&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='id_country']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='yui_3_17_2_1_1641442754528_787']/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chọn quốc gia'])[1]/following::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tỉnh/Thành phố'])[1]/following::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Múi giờ'])[1]/preceding::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ngôn ngữ ưa thích'])[1]/preceding::select[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[14]/div[2]/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='yui_3_17_2_1_1641375718034_814']/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='yui_3_17_2_1_1641292236714_803']/select</value>
   </webElementXpaths>
</WebElementEntity>
